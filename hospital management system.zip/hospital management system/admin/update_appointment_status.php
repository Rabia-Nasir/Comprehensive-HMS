<?php
session_start();
require '../db.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Check if required parameters are provided
if (!isset($_POST['appointment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing appointment ID']);
    exit;
}

$appointment_id = $_POST['appointment_id'];
$response = ['success' => false];

// Handle appointment rescheduling
if (isset($_POST['new_date']) && isset($_POST['new_time'])) {
    $new_date = $_POST['new_date'];
    $new_time = $_POST['new_time'];
    
    // Validate date and time format
    if (!strtotime($new_date) || !strtotime($new_time)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid date or time format']);
        exit;
    }
    
    try {
        // Check for conflicting appointments
        $stmt = $conn->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = (SELECT doctor_id FROM appointments WHERE appointment_id = ?) AND appointment_date = ? AND appointment_time = ? AND appointment_id != ? AND status != 'cancelled'");
        $stmt->execute([$appointment_id, $new_date, $new_time, $appointment_id]);
        $conflicts = $stmt->fetchColumn();
        
        if ($conflicts > 0) {
            echo json_encode(['error' => 'Selected time slot is already booked']);
            exit;
        }
        
        // Update appointment date and time
        $stmt = $conn->prepare("UPDATE appointments SET appointment_date = ?, appointment_time = ?, status = 'rescheduled' WHERE appointment_id = ?");
        $stmt->execute([$new_date, $new_time, $appointment_id]);
        
        $response = [
            'success' => true,
            'message' => 'Appointment rescheduled successfully',
            'new_date' => $new_date,
            'new_time' => $new_time
        ];
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        exit;
    }
}
// Handle status updates
else if (isset($_POST['status'])) {
    $status = $_POST['status'];
    
    // Validate status
    if (!in_array($status, ['confirmed', 'cancelled', 'rescheduled'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid status']);
        exit;
    }
    
    try {
        $stmt = $conn->prepare("UPDATE appointments SET status = ? WHERE appointment_id = ?");
        $stmt->execute([$status, $appointment_id]);
        
        // Fetch appointment details for response
        $stmt = $conn->prepare("SELECT a.*, u.full_name as patient_name, d.doctor_name 
            FROM appointments a 
            JOIN users u ON a.patient_id = u.user_id 
            JOIN doctors d ON a.doctor_id = d.doctor_id 
            WHERE a.appointment_id = ?");
        $stmt->execute([$appointment_id]);
        $appointment = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $response = [
            'success' => true,
            'message' => 'Appointment status updated successfully',
            'appointment' => [
                'status' => $status,
                'date' => $appointment['appointment_date'],
                'time' => $appointment['appointment_time'],
                'patient_name' => $appointment['patient_name'],
                'doctor_name' => $appointment['doctor_name']
            ]
        ];
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        exit;
    }
}

echo json_encode($response);