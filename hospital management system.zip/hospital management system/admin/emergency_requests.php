<?php
session_start();
require '../db.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $emergency_id = $_POST['emergency_id'];
    $status = $_POST['update_status'];
    
    try {
        if ($status === 'completed') {
            // When marking as completed, increment available beds
            $stmt = $conn->prepare("
                UPDATE hospitals h
                JOIN emergency_requests e ON h.hospital_id = e.assigned_hospital_id
                SET h.available_beds = h.available_beds + 1,
                    e.status = 'completed'
                WHERE e.emergency_id = ? AND e.assigned_hospital_id = ?
            ");
            $stmt->execute([$emergency_id, $_SESSION['hospital_id']]);
        } else {
            $stmt = $conn->prepare("UPDATE emergency_requests SET status = ? WHERE emergency_id = ? AND assigned_hospital_id = ?");
            $stmt->execute([$status, $emergency_id, $_SESSION['hospital_id']]);
        }
        $success_message = "Status updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error updating status: " . $e->getMessage();
    }
}

// Fetch emergency requests for this hospital
try {
    $stmt = $conn->prepare("
        SELECT e.*, h.hospital_name 
        FROM emergency_requests e
        LEFT JOIN hospitals h ON e.assigned_hospital_id = h.hospital_id
        WHERE e.assigned_hospital_id = ?
        ORDER BY e.created_at DESC
    ");
    $stmt->execute([$_SESSION['hospital_id']]);
    $emergencies = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_message = "Error fetching emergencies: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency Requests - Hospital System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .emergency-card {
            border-left: 4px solid #dc3545;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
        }
        .status-pending {
            background: #ffc107;
            color: #000;
        }
        .status-accepted {
            background: #28a745;
            color: #fff;
        }
        .status-completed {
            background: #6c757d;
            color: #fff;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Emergency Requests</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">Dashboard</a>
                <a class="nav-link" href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <h2>Emergency Requests</h2>
                
                <?php if (empty($emergencies)): ?>
                    <div class="alert alert-info">No emergency requests found.</div>
                <?php else: ?>
                    <?php foreach ($emergencies as $emergency): ?>
                        <div class="emergency-card">
                            <div class="d-flex justify-content-between align-items-center">
                                <h4><?php echo htmlspecialchars($emergency['patient_name']); ?></h4>
                                <span class="status-badge status-<?php echo strtolower($emergency['status']); ?>">
                                    <?php echo ucfirst($emergency['status']); ?>
                                </span>
                            </div>
                            
                            <p><strong>Phone:</strong> <?php echo htmlspecialchars($emergency['phone']); ?></p>
                            <p><strong>Address:</strong> <?php echo htmlspecialchars($emergency['address']); ?></p>
                            <p><strong>Emergency Type:</strong> <?php echo htmlspecialchars($emergency['emergency_type']); ?></p>
                            <?php if ($emergency['description']): ?>
                                <p><strong>Description:</strong> <?php echo htmlspecialchars($emergency['description']); ?></p>
                            <?php endif; ?>
                            <p><strong>Request Time:</strong> <?php echo date('F j, Y g:i A', strtotime($emergency['created_at'])); ?></p>

                            <?php if ($emergency['status'] !== 'completed'): ?>
                                <form method="POST" class="mt-3">
                                    <input type="hidden" name="emergency_id" value="<?php echo $emergency['emergency_id']; ?>">
                                    <div class="btn-group">
                                        <button type="submit" name="update_status" value="accepted" class="btn btn-success">
                                            Accept Request
                                        </button>
                                        <button type="submit" name="update_status" value="completed" class="btn btn-primary">
                                            Mark as Completed
                                        </button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 