<?php
session_start();
require '../db.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Check if hospital ID is provided
if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit;
}

$hospital_id = $_GET['id'];

try {
    // Start transaction
    $conn->beginTransaction();

    // Update users to remove hospital association
    $stmt = $conn->prepare("UPDATE users SET hospital_id = NULL WHERE hospital_id = ?");
    $stmt->execute([$hospital_id]);

    // Delete the hospital
    $stmt = $conn->prepare("DELETE FROM hospitals WHERE hospital_id = ?");
    $stmt->execute([$hospital_id]);

    // Commit transaction
    $conn->commit();

    $_SESSION['success_message'] = "Hospital and associated doctors deleted successfully.";
} catch (PDOException $e) {
    // Rollback transaction on error
    $conn->rollBack();
    $_SESSION['error_message'] = "Error deleting hospital: " . $e->getMessage();
}

// Redirect back to dashboard
header("Location: dashboard.php");
exit;