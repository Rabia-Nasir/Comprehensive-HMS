<?php
session_start();
require '../db.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Check if hospital ID is provided
if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit;
}

$hospital_id = $_GET['id'];
$error_message = '';
$success_message = '';

// Fetch hospital details
try {
    $stmt = $conn->prepare("SELECT * FROM hospitals WHERE hospital_id = ?");
    $stmt->execute([$hospital_id]);
    $hospital = $stmt->fetch();

    if (!$hospital) {
        header("Location: dashboard.php");
        exit;
    }

    // Fetch doctors for this hospital
    $stmt = $conn->prepare("SELECT * FROM doctors WHERE hospital_id = ?");
    $stmt->execute([$hospital_id]);
    $doctors = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_message = "Error fetching data: " . $e->getMessage();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_hospital'])) {
        $hospital_name = $_POST['hospital_name'];
        $hospital_address = $_POST['hospital_address'];
        $contact_number = $_POST['contact_number'];
        $total_beds = $_POST['total_beds'];
        $available_beds = $_POST['available_beds'];

        try {
            $stmt = $conn->prepare("UPDATE hospitals SET hospital_name = ?, address = ?, contact_number = ?, total_beds = ?, available_beds = ? WHERE hospital_id = ?");
            $stmt->execute([$hospital_name, $hospital_address, $contact_number, $total_beds, $available_beds, $hospital_id]);
            $success_message = "Hospital details updated successfully!";
            
            // Refresh hospital data
            $stmt = $conn->prepare("SELECT * FROM hospitals WHERE hospital_id = ?");
            $stmt->execute([$hospital_id]);
            $hospital = $stmt->fetch();
        } catch (PDOException $e) {
            $error_message = "Error updating hospital: " . $e->getMessage();
        }
    } elseif (isset($_POST['add_doctor'])) {
        $doctor_name = $_POST['doctor_name'];
        $doctor_email = $_POST['doctor_email'];
        $doctor_phone = $_POST['doctor_phone'];
        $doctor_specialization = $_POST['doctor_specialization'];

        try {
            // Add new doctor to doctors table
            $stmt = $conn->prepare("INSERT INTO doctors (hospital_id, doctor_name, email, phone, specialization) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$hospital_id, $doctor_name, $doctor_email, $doctor_phone, $doctor_specialization]);
            $success_message = "Doctor added successfully!";

            // Refresh doctors list
            $stmt = $conn->prepare("SELECT * FROM doctors WHERE hospital_id = ?");
            $stmt->execute([$hospital_id]);
            $doctors = $stmt->fetchAll();
        } catch (PDOException $e) {
            $error_message = "Error adding doctor: " . $e->getMessage();
        }
    } elseif (isset($_POST['remove_doctor'])) {
        $doctor_id = $_POST['doctor_id'];

        try {
            $stmt = $conn->prepare("DELETE FROM doctors WHERE doctor_id = ? AND hospital_id = ?");
            $stmt->execute([$doctor_id, $hospital_id]);
            $success_message = "Doctor removed successfully!";

            // Refresh doctors list
            $stmt = $conn->prepare("SELECT * FROM doctors WHERE hospital_id = ?");
            $stmt->execute([$hospital_id]);
            $doctors = $stmt->fetchAll();
        } catch (PDOException $e) {
            $error_message = "Error removing doctor: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Hospital - Hospital Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Edit Hospital</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">Back to Dashboard</a>
                <a class="nav-link" href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Edit Hospital Details</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Hospital Name</label>
                                <input type="text" name="hospital_name" class="form-control" value="<?php echo htmlspecialchars($hospital['hospital_name']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <textarea name="hospital_address" class="form-control" required><?php echo htmlspecialchars($hospital['address']); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Contact Number</label>
                                <input type="tel" name="contact_number" class="form-control" value="<?php echo htmlspecialchars($hospital['contact_number']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Total Beds</label>
                                <input type="number" name="total_beds" class="form-control" value="<?php echo $hospital['total_beds']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Available Beds</label>
                                <input type="number" name="available_beds" class="form-control" value="<?php echo $hospital['available_beds']; ?>" required>
                            </div>
                            <button type="submit" name="update_hospital" class="btn btn-primary">Update Hospital</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Add New Doctor</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Doctor Name</label>
                                <input type="text" name="doctor_name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="doctor_email" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Phone</label>
                                <input type="tel" name="doctor_phone" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Specialization</label>
                                <input type="text" name="doctor_specialization" class="form-control" required>
                            </div>
                            <button type="submit" name="add_doctor" class="btn btn-success">Add Doctor</button>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Manage Doctors</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Specialization</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($doctors as $doctor): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($doctor['doctor_name']); ?></td>
                                        <td><?php echo htmlspecialchars($doctor['email'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($doctor['phone'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($doctor['specialization']); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="doctor_id" value="<?php echo $doctor['doctor_id']; ?>">
                                                <button type="submit" name="remove_doctor" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to remove this doctor?')">Remove</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>