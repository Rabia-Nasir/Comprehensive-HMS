<?php
session_start();
require '../db.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Fetch all hospitals
$stmt = $conn->prepare("SELECT * FROM hospitals");
$stmt->execute();
$hospitals = $stmt->fetchAll();

// Add new hospital
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_hospital'])) {
    $hospital_name = $_POST['hospital_name'];
    $hospital_address = $_POST['hospital_address'];
    $contact_number = $_POST['contact_number'];
    $total_beds = $_POST['total_beds'];
    $available_beds = $_POST['available_beds'];

    try {
        $stmt = $conn->prepare("INSERT INTO hospitals (hospital_name, address, contact_number, total_beds, available_beds) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$hospital_name, $hospital_address, $contact_number, $total_beds, $available_beds]);
        header("Location: dashboard.php");
        exit;
    } catch (PDOException $e) {
        $error_message = "Error creating hospital: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Hospital Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Add New Hospital</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Hospital Name</label>
                                <input type="text" name="hospital_name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <textarea name="hospital_address" class="form-control" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Contact Number</label>
                                <input type="tel" name="contact_number" class="form-control" pattern="[0-9]{10}" title="Please enter a valid 10-digit phone number" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Total Beds</label>
                                <input type="number" name="total_beds" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Available Beds</label>
                                <input type="number" name="available_beds" class="form-control" required>
                            </div>
                            <button type="submit" name="add_hospital" class="btn btn-primary">Add Hospital</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Managed Hospitals</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Hospital Name</th>
                                        <th>Address</th>
                                        <th>Contact</th>
                                        <th>Total Beds</th>
                                        <th>Available Beds</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($hospitals as $hospital): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($hospital['hospital_name']); ?></td>
                                        <td><?php echo htmlspecialchars($hospital['address']); ?></td>
                                        <td><?php echo htmlspecialchars($hospital['contact_number']); ?></td>
                                        <td><?php echo $hospital['total_beds']; ?></td>
                                        <td><?php echo $hospital['available_beds']; ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary" onclick="editHospital(<?php echo $hospital['hospital_id']; ?>)">Edit</button>
                                            <button class="btn btn-sm btn-danger" onclick="deleteHospital(<?php echo $hospital['hospital_id']; ?>)">Delete</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Upcoming Appointments</h5>
                        <small class="text-muted">Showing appointments scheduled for today and future dates</small>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Patient Name</th>
                                        <th>Doctor Name</th>
                                        <th>Hospital</th>
                                        <th>Date & Time</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Fetch upcoming appointments
                                    $stmt = $conn->prepare("SELECT a.*, u.full_name as patient_name, d.doctor_name, h.hospital_name 
                                        FROM appointments a 
                                        JOIN users u ON a.patient_id = u.user_id 
                                        JOIN doctors d ON a.doctor_id = d.doctor_id 
                                        JOIN hospitals h ON d.hospital_id = h.hospital_id 
                                        WHERE (a.appointment_date > CURRENT_DATE) 
                                        OR (a.appointment_date = CURRENT_DATE AND a.appointment_time >= CURRENT_TIME) 
                                        ORDER BY a.appointment_date ASC, a.appointment_time ASC");
                                    $stmt->execute();
                                    $appointments = $stmt->fetchAll();

                                    foreach ($appointments as $appointment):
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($appointment['patient_name']); ?></td>
                                        <td><?php echo htmlspecialchars($appointment['doctor_name']); ?></td>
                                        <td><?php echo htmlspecialchars($appointment['hospital_name']); ?></td>
                                        <td>
                                            <div><?php echo date('Y-m-d', strtotime($appointment['appointment_date'])); ?></div>
                                            <small class="text-muted"><?php echo date('H:i', strtotime($appointment['appointment_time'])); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $appointment['status'] === 'confirmed' ? 'success' : 
                                                    ($appointment['status'] === 'pending' ? 'warning' : 
                                                        ($appointment['status'] === 'rescheduled' ? 'info' : 'danger')); 
                                                ?>">
                                                <?php echo ucfirst($appointment['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-success" onclick="updateAppointmentStatus(<?php echo $appointment['appointment_id']; ?>, 'confirmed')">Confirm</button>
                                            <button class="btn btn-sm btn-primary" onclick="showRescheduleModal(<?php echo $appointment['appointment_id']; ?>)">Reschedule</button>
                                            <button class="btn btn-sm btn-danger" onclick="updateAppointmentStatus(<?php echo $appointment['appointment_id']; ?>, 'cancelled')">Cancel</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Manage Doctors</h5>
                        <p class="card-text">Add, edit, or remove doctors from your hospital.</p>
                        <a href="doctors.php" class="btn btn-primary">Manage Doctors</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Emergency Requests</h5>
                        <p class="card-text">View and manage emergency requests.</p>
                        <a href="emergency_requests.php" class="btn btn-danger">View Emergencies</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Hospital Profile</h5>
                        <p class="card-text">Update your hospital's information.</p>
                        <a href="edit_hospital.php" class="btn btn-info">Edit Profile</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Reschedule Modal -->
    <div class="modal fade" id="rescheduleModal" tabindex="-1" aria-labelledby="rescheduleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="rescheduleModalLabel">Reschedule Appointment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="rescheduleForm">
                        <input type="hidden" id="appointmentId" name="appointment_id">
                        <div class="mb-3">
                            <label for="newDate" class="form-label">New Date</label>
                            <input type="date" class="form-control" id="newDate" name="new_date" required>
                        </div>
                        <div class="mb-3">
                            <label for="newTime" class="form-label">New Time</label>
                            <input type="time" class="form-control" id="newTime" name="new_time" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="rescheduleAppointment()">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editHospital(id) {
            window.location.href = `edit_hospital.php?id=${id}`;
        }

        function deleteHospital(id) {
            if (confirm('Are you sure you want to delete this hospital?')) {
                window.location.href = `delete_hospital.php?id=${id}`;
            }
        }

        let rescheduleModal;
        document.addEventListener('DOMContentLoaded', function() {
            rescheduleModal = new bootstrap.Modal(document.getElementById('rescheduleModal'));
        });

        function showRescheduleModal(appointmentId) {
            document.getElementById('appointmentId').value = appointmentId;
            // Set minimum date to today
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('newDate').min = today;
            rescheduleModal.show();
        }

        function rescheduleAppointment() {
            const form = document.getElementById('rescheduleForm');
            const formData = new FormData(form);
            const data = new URLSearchParams(formData);

            fetch('update_appointment_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: data
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Appointment rescheduled successfully');
                    rescheduleModal.hide();
                    location.reload();
                } else {
                    alert(data.error || 'Failed to reschedule appointment');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while rescheduling the appointment');
            });
        }

        function updateAppointmentStatus(appointmentId, status) {
            if (!confirm(`Are you sure you want to ${status} this appointment?`)) {
                return;
            }

            fetch('update_appointment_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `appointment_id=${appointmentId}&status=${status}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Appointment status updated successfully');
                    location.reload();
                } else {
                    alert(data.error || 'Failed to update appointment status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the appointment status');
            });
        }
    </script>
</body>
</html>