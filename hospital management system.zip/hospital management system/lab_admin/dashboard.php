<?php
session_start();
require '../db.php';

// Check if user is logged in and is a lab admin
if (!isset($_SESSION['lab_admin_id']) || !isset($_SESSION['lab_id'])) {
    header("Location: login.php");
    exit;
}

// Get lab information
$stmt = $conn->prepare("SELECT * FROM laboratories WHERE lab_id = ?");
$stmt->execute([$_SESSION['lab_id']]);
$lab = $stmt->fetch();

// Get lab tests
$stmt = $conn->prepare("SELECT * FROM lab_tests WHERE lab_id = ?");
$stmt->execute([$_SESSION['lab_id']]);
$tests = $stmt->fetchAll();

// Get appointments
$stmt = $conn->prepare("
    SELECT la.*, lt.test_name, u.username as patient_name 
    FROM lab_appointments la 
    JOIN lab_tests lt ON la.test_id = lt.test_id 
    JOIN users u ON la.patient_id = u.user_id 
    WHERE la.lab_id = ? 
    ORDER BY la.appointment_date DESC
");
$stmt->execute([$_SESSION['lab_id']]);
$appointments = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Lab Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="manage_tests.php">Manage Tests</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="appointments.php">Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Laboratory Information</h4>
                    </div>
                    <div class="card-body">
                        <p><strong>Lab Name:</strong> <?php echo htmlspecialchars($lab['lab_name']); ?></p>
                        <p><strong>Address:</strong> <?php echo htmlspecialchars($lab['address']); ?></p>
                        <p><strong>Contact:</strong> <?php echo htmlspecialchars($lab['contact_number']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($lab['email']); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Available Tests</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($tests)): ?>
                            <p>No tests available.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Test Name</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($tests as $test): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($test['test_name']); ?></td>
                                                <td>₹<?php echo htmlspecialchars($test['price']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $test['availability'] ? 'success' : 'danger'; ?>">
                                                        <?php echo $test['availability'] ? 'Available' : 'Unavailable'; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        <a href="manage_tests.php" class="btn btn-primary">Manage Tests</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Recent Appointments</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($appointments)): ?>
                            <p>No appointments found.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Patient</th>
                                            <th>Test</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($appointments as $appointment): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($appointment['patient_name']); ?></td>
                                                <td><?php echo htmlspecialchars($appointment['test_name']); ?></td>
                                                <td><?php echo date('d M Y H:i', strtotime($appointment['appointment_date'])); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $appointment['status'] === 'completed' ? 'success' : 
                                                            ($appointment['status'] === 'pending' ? 'warning' : 'info'); 
                                                    ?>">
                                                        <?php echo ucfirst($appointment['status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        <a href="appointments.php" class="btn btn-primary">View All Appointments</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 