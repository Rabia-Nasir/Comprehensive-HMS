<?php
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lab_admin_id = $_POST['lab_admin_id'];
    $lab_id = $_POST['lab_id'];
    
    try {
        // Update the lab admin's lab_id
        $stmt = $conn->prepare("UPDATE users SET lab_id = ? WHERE user_id = ? AND user_type = 'lab_admin'");
        $stmt->execute([$lab_id, $lab_admin_id]);
        
        $_SESSION['success_message'] = "Laboratory assigned successfully!";
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error assigning laboratory: " . $e->getMessage();
    }
    
    header("Location: check_lab_admin.php");
    exit;
}
?> 