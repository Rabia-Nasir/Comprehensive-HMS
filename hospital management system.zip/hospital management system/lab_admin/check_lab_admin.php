<?php
require '../db.php';

// Check lab admins
$stmt = $conn->query("
    SELECT u.*, l.lab_name, l.address 
    FROM users u 
    LEFT JOIN laboratories l ON u.lab_id = l.lab_id 
    WHERE u.user_type = 'lab_admin'
");
$lab_admins = $stmt->fetchAll();

// Check laboratories
$stmt = $conn->query("SELECT * FROM laboratories");
$laboratories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Admin Check</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Lab Admin Check</h2>
        
        <div class="row mt-4">
            <div class="col-md-6">
                <h3>Lab Admins</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Lab ID</th>
                            <th>Lab Name</th>
                            <th>Lab Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lab_admins as $admin): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($admin['username']); ?></td>
                                <td><?php echo $admin['lab_id'] ?? 'NULL'; ?></td>
                                <td><?php echo htmlspecialchars($admin['lab_name'] ?? 'Not assigned'); ?></td>
                                <td><?php echo htmlspecialchars($admin['address'] ?? 'Not assigned'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="col-md-6">
                <h3>Laboratories</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Lab ID</th>
                            <th>Lab Name</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($laboratories as $lab): ?>
                            <tr>
                                <td><?php echo $lab['lab_id']; ?></td>
                                <td><?php echo htmlspecialchars($lab['lab_name']); ?></td>
                                <td><?php echo htmlspecialchars($lab['address']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="mt-4">
            <h3>Fix Lab Admin Assignments</h3>
            <form method="POST" action="fix_lab_admin.php">
                <div class="mb-3">
                    <label for="lab_admin" class="form-label">Select Lab Admin</label>
                    <select class="form-select" id="lab_admin" name="lab_admin_id" required>
                        <option value="">Select a lab admin</option>
                        <?php foreach ($lab_admins as $admin): ?>
                            <option value="<?php echo $admin['user_id']; ?>">
                                <?php echo htmlspecialchars($admin['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label for="laboratory" class="form-label">Select Laboratory</label>
                    <select class="form-select" id="laboratory" name="lab_id" required>
                        <option value="">Select a laboratory</option>
                        <?php foreach ($laboratories as $lab): ?>
                            <option value="<?php echo $lab['lab_id']; ?>">
                                <?php echo htmlspecialchars($lab['lab_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">Assign Laboratory</button>
            </form>
        </div>
    </div>
</body>
</html> 