<?php
session_start();
require '../db.php';

// Check if user is logged in and is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'patient') {
    header("Location: ../index.php");
    exit;
}

// Handle medicine purchase
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['medicine_id']) && isset($_POST['quantity'])) {
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];
    $pharmacy_id = $_POST['pharmacy_id'];

    try {
        // Start transaction
        $conn->beginTransaction();

        // Check if medicine exists and has enough quantity
        $stmt = $conn->prepare("
            SELECT quantity, price 
            FROM medicines 
            WHERE medicine_id = ? AND pharmacy_id = ?
        ");
        $stmt->execute([$medicine_id, $pharmacy_id]);
        $medicine = $stmt->fetch();

        if (!$medicine) {
            throw new Exception("Medicine not found");
        }

        if ($medicine['quantity'] < $quantity) {
            throw new Exception("Not enough quantity in stock");
        }

        // Calculate total amount
        $total_amount = $medicine['price'] * $quantity;

        // Create the sale record
        $stmt = $conn->prepare("
            INSERT INTO medicine_sales (pharmacy_id, medicine_id, quantity, price, total_amount) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$pharmacy_id, $medicine_id, $quantity, $medicine['price'], $total_amount]);

        // Update medicine quantity
        $stmt = $conn->prepare("
            UPDATE medicines 
            SET quantity = quantity - ? 
            WHERE medicine_id = ? AND pharmacy_id = ?
        ");
        $stmt->execute([$quantity, $medicine_id, $pharmacy_id]);

        $conn->commit();
        $_SESSION['success_message'] = "Purchase successful! Total amount: ₹" . number_format($total_amount, 2);
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error_message'] = "Error: " . $e->getMessage();
    }
}

// Get all pharmacies
$stmt = $conn->prepare("SELECT * FROM pharmacies ORDER BY name");
$stmt->execute();
$pharmacies = $stmt->fetchAll();

// Get selected pharmacy's medicines
$selected_pharmacy_id = isset($_GET['pharmacy_id']) ? $_GET['pharmacy_id'] : null;
$medicines = [];

if ($selected_pharmacy_id) {
    $stmt = $conn->prepare("
        SELECT * FROM medicines 
        WHERE pharmacy_id = ? AND quantity > 0 
        ORDER BY name
    ");
    $stmt->execute([$selected_pharmacy_id]);
    $medicines = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Medicines - Patient</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        .medicine-card {
            transition: transform 0.2s;
        }
        .medicine-card:hover {
            transform: translateY(-5px);
        }
        .pharmacy-info {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Patient Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="buy_medicines.php">Buy Medicines</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="appointments.php">Appointments</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Select Pharmacy</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <?php foreach ($pharmacies as $pharmacy): ?>
                                <a href="?pharmacy_id=<?php echo $pharmacy['pharmacy_id']; ?>" 
                                   class="list-group-item list-group-item-action <?php echo $selected_pharmacy_id == $pharmacy['pharmacy_id'] ? 'active' : ''; ?>">
                                    <?php echo htmlspecialchars($pharmacy['name']); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-9">
                <?php if ($selected_pharmacy_id): ?>
                    <?php 
                    // Get pharmacy details
                    $stmt = $conn->prepare("SELECT * FROM pharmacies WHERE pharmacy_id = ?");
                    $stmt->execute([$selected_pharmacy_id]);
                    $pharmacy = $stmt->fetch();
                    ?>
                    <div class="pharmacy-info">
                        <h4><?php echo htmlspecialchars($pharmacy['name']); ?></h4>
                        <p class="mb-1"><i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($pharmacy['address']); ?></p>
                        <p class="mb-1"><i class="bi bi-telephone"></i> <?php echo htmlspecialchars($pharmacy['contact_number']); ?></p>
                        <p class="mb-0"><i class="bi bi-envelope"></i> <?php echo htmlspecialchars($pharmacy['email']); ?></p>
                    </div>

                    <div class="row">
                        <?php foreach ($medicines as $medicine): ?>
                            <div class="col-md-4 mb-4">
                                <div class="card medicine-card h-100">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo htmlspecialchars($medicine['name']); ?></h5>
                                        <p class="card-text"><?php echo htmlspecialchars($medicine['description']); ?></p>
                                        <p class="card-text">
                                            <strong>Price:</strong> ₹<?php echo number_format($medicine['price'], 2); ?><br>
                                            <strong>Available:</strong> <?php echo $medicine['quantity']; ?> units
                                        </p>
                                        <button type="button" class="btn btn-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#buyModal<?php echo $medicine['medicine_id']; ?>">
                                            Buy Now
                                        </button>
                                    </div>
                                </div>

                                <!-- Buy Modal -->
                                <div class="modal fade" id="buyModal<?php echo $medicine['medicine_id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Buy <?php echo htmlspecialchars($medicine['name']); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST" action="">
                                                <div class="modal-body">
                                                    <input type="hidden" name="medicine_id" value="<?php echo $medicine['medicine_id']; ?>">
                                                    <input type="hidden" name="pharmacy_id" value="<?php echo $selected_pharmacy_id; ?>">
                                                    
                                                    <div class="mb-3">
                                                        <label class="form-label">Price per Unit</label>
                                                        <input type="text" class="form-control" value="₹<?php echo number_format($medicine['price'], 2); ?>" readonly>
                                                    </div>
                                                    
                                                    <div class="mb-3">
                                                        <label for="quantity" class="form-label">Quantity</label>
                                                        <input type="number" class="form-control" id="quantity" name="quantity" 
                                                               min="1" max="<?php echo $medicine['quantity']; ?>" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-primary">Confirm Purchase</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        Please select a pharmacy to view available medicines.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 