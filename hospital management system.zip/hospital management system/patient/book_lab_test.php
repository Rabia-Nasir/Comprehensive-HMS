<?php
session_start();
require '../db.php';

// Check if user is logged in and is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'patient') {
    header("Location: ../index.php");
    exit;
}

$selected_lab_id = null;
$available_tests = [];
$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['select_lab'])) {
        $selected_lab_id = $_POST['lab_id'];
    } elseif (isset($_POST['book_appointment'])) {
        try {
            $lab_id = $_POST['lab_id'];
            $test_id = $_POST['test_id'];
            $appointment_date = $_POST['appointment_date'];
            $appointment_time = $_POST['appointment_time'];
            $patient_id = $_SESSION['user_id'];

            // Start transaction
            $conn->beginTransaction();

            // Insert appointment
            $stmt = $conn->prepare("
                INSERT INTO lab_appointments 
                (patient_id, lab_id, test_id, appointment_date, appointment_time, status) 
                VALUES (?, ?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([$patient_id, $lab_id, $test_id, $appointment_date, $appointment_time]);

            $conn->commit();
            $success_message = "Appointment booked successfully!";
        } catch (PDOException $e) {
            $conn->rollBack();
            $error_message = "Error booking appointment: " . $e->getMessage();
        }
    }
}

// Fetch all laboratories
$stmt = $conn->query("SELECT * FROM laboratories ORDER BY lab_name");
$laboratories = $stmt->fetchAll();

// If a lab is selected, fetch its available tests
if ($selected_lab_id) {
    $stmt = $conn->prepare("
        SELECT * FROM lab_tests 
        WHERE lab_id = ? AND is_available = TRUE 
        ORDER BY test_name
    ");
    $stmt->execute([$selected_lab_id]);
    $available_tests = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Lab Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .lab-card {
            border-left: 4px solid #0d6efd;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            transition: all 0.3s ease;
        }
        .lab-card:hover {
            transform: translateX(5px);
        }
        .test-card {
            border-left: 4px solid #198754;
            margin-bottom: 15px;
            padding: 15px;
            background: #f8f9fa;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Book Lab Test</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="buy_medicines.php">Buy Medicines</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="book_lab_test.php">Book Lab Test</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Select Laboratory</h4>
                    </div>
                    <div class="card-body">
                        <?php foreach ($laboratories as $lab): ?>
                            <div class="lab-card">
                                <h5><?php echo htmlspecialchars($lab['lab_name']); ?></h5>
                                <p class="mb-1"><small><strong>Address:</strong> <?php echo htmlspecialchars($lab['address']); ?></small></p>
                                <p class="mb-1"><small><strong>Contact:</strong> <?php echo htmlspecialchars($lab['contact_number']); ?></small></p>
                                <form method="POST" class="mt-2">
                                    <input type="hidden" name="lab_id" value="<?php echo $lab['lab_id']; ?>">
                                    <button type="submit" name="select_lab" class="btn btn-primary btn-sm">
                                        Select Lab
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <?php if ($selected_lab_id): ?>
                    <div class="card">
                        <div class="card-header">
                            <h4>Available Tests</h4>
                        </div>
                        <div class="card-body">
                            <?php if (empty($available_tests)): ?>
                                <div class="alert alert-info">No tests available at this laboratory.</div>
                            <?php else: ?>
                                <?php foreach ($available_tests as $test): ?>
                                    <div class="test-card">
                                        <h5><?php echo htmlspecialchars($test['test_name']); ?></h5>
                                        <p class="mb-1"><strong>Description:</strong> <?php echo htmlspecialchars($test['description']); ?></p>
                                        <p class="mb-1"><strong>Price:</strong> $<?php echo number_format($test['price'], 2); ?></p>
                                        <p class="mb-1"><strong>Preparation:</strong> <?php echo htmlspecialchars($test['preparation_instructions']); ?></p>
                                        <p class="mb-1"><strong>Estimated Time:</strong> <?php echo htmlspecialchars($test['estimated_time']); ?></p>
                                        
                                        <button type="button" class="btn btn-success btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#bookModal<?php echo $test['test_id']; ?>">
                                            Book Test
                                        </button>

                                        <!-- Booking Modal -->
                                        <div class="modal fade" id="bookModal<?php echo $test['test_id']; ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Book <?php echo htmlspecialchars($test['test_name']); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="lab_id" value="<?php echo $selected_lab_id; ?>">
                                                            <input type="hidden" name="test_id" value="<?php echo $test['test_id']; ?>">
                                                            
                                                            <div class="mb-3">
                                                                <label for="appointment_date" class="form-label">Appointment Date</label>
                                                                <input type="date" class="form-control" id="appointment_date" name="appointment_date" required 
                                                                       min="<?php echo date('Y-m-d'); ?>">
                                                            </div>
                                                            
                                                            <div class="mb-3">
                                                                <label for="appointment_time" class="form-label">Appointment Time</label>
                                                                <input type="time" class="form-control" id="appointment_time" name="appointment_time" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" name="book_appointment" class="btn btn-primary">Book Appointment</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        Please select a laboratory to view available tests.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 