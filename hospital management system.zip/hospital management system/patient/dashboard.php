<?php
session_start();
require '../db.php';

// Check if user is logged in and is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'patient') {
    header("Location: ../index.php");
    exit;
}

// Fetch patient's appointments
$stmt = $conn->prepare("
    SELECT a.*, d.doctor_name, h.hospital_name 
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.doctor_id
    JOIN hospitals h ON d.hospital_id = h.hospital_id
    WHERE a.patient_id = ?
    ORDER BY a.appointment_date DESC
");
$stmt->execute([$_SESSION['user_id']]);
$appointments = $stmt->fetchAll();

// Fetch all hospitals with their available beds
$query = "SELECT * FROM hospitals ORDER BY hospital_name";
$hospitals = $conn->query($query)->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .dashboard-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .appointment-card {
            border-left: 4px solid #4CAF50;
            margin-bottom: 15px;
            padding: 15px;
            background: #f8f9fa;
        }
        .hospital-card {
            border-left: 4px solid #007bff;
            margin-bottom: 10px;
            padding: 10px;
            background: #f8f9fa;
            transition: all 0.3s ease;
        }
        .hospital-card:hover {
            transform: translateX(5px);
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Patient Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="buy_medicines.php">Buy Medicines</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="appointments.php">Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="book_lab_test.php">Lab Tests</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <div class="dashboard-card">
                    <h4>Quick Actions</h4>
                    <div class="d-grid gap-2">
                        <a href="../search_hospitals.php" class="btn btn-primary">Search Hospitals</a>
                        <a href="buy_medicines.php" class="btn btn-success">Buy Medicines</a>
                        <a href="appointments.php" class="btn btn-info text-white">Book Appointment</a>
                        <a href="book_lab_test.php" class="btn btn-warning">Book Lab Test</a>
                    </div>
                </div>

                <div class="dashboard-card">
                    <h4>Available Hospitals</h4>
                    <?php foreach ($hospitals as $hospital): ?>
                        <div class="hospital-card">
                            <h5><?php echo htmlspecialchars($hospital['hospital_name']); ?></h5>
                            <p class="mb-1"><small><strong>Address:</strong> <?php echo htmlspecialchars($hospital['address']); ?></small></p>
                            <p class="mb-1"><small><strong>Contact:</strong> <?php echo htmlspecialchars($hospital['contact_number']); ?></small></p>
                            <p class="mb-0"><strong>Available Beds:</strong> <span class="text-success"><?php echo $hospital['available_beds']; ?></span> / <?php echo $hospital['total_beds']; ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="col-md-8">
                <div class="dashboard-card">
                    <h4>My Appointments</h4>
                    <?php if (empty($appointments)): ?>
                        <p class="text-muted">No appointments found.</p>
                    <?php else: ?>
                        <?php foreach ($appointments as $appointment): ?>
                            <div class="appointment-card">
                                <h5><?php echo htmlspecialchars($appointment['hospital_name']); ?></h5>
                                <p>Doctor: <?php echo htmlspecialchars($appointment['doctor_name']); ?></p>
                                <p>Date: <?php echo date('F d, Y', strtotime($appointment['appointment_date'])); ?></p>
                                <p>Time: <?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></p>
                                <p>Status: <span class="badge bg-<?php echo $appointment['status'] === 'confirmed' ? 'success' : ($appointment['status'] === 'pending' ? 'warning' : 'danger'); ?>">
                                    <?php echo ucfirst($appointment['status']); ?>
                                </span></p>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>