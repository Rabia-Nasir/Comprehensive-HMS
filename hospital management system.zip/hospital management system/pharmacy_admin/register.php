<?php
session_start();
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $pharmacy_name = $_POST['pharmacy_name'];
    $address = $_POST['address'];
    $contact_number = $_POST['contact_number'];
    $pharmacy_email = $_POST['pharmacy_email'];

    try {
        // Start transaction
        $conn->beginTransaction();

        // First, check if username already exists
        $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("Username already exists");
        }

        // Insert the pharmacy
        $stmt = $conn->prepare("INSERT INTO pharmacies (name, address, contact_number, email) VALUES (?, ?, ?, ?)");
        $stmt->execute([$pharmacy_name, $address, $contact_number, $pharmacy_email]);
        $pharmacy_id = $conn->lastInsertId();

        // Create the pharmacy admin user
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, password, email, user_type, pharmacy_id) VALUES (?, ?, ?, 'pharmacy_admin', ?)");
        $stmt->execute([$username, $hashed_password, $email, $pharmacy_id]);

        // Verify the user was created
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if (!$user) {
            throw new Exception("Failed to create user");
        }

        $conn->commit();
        $_SESSION['success_message'] = "Pharmacy admin account created successfully! You can now login.";
        header("Location: login.php");
        exit;
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error_message'] = "Registration failed: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Pharmacy Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Register Pharmacy Admin</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_SESSION['error_message'])): ?>
                            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="pharmacy_name" class="form-label">Pharmacy Name</label>
                                <input type="text" class="form-control" id="pharmacy_name" name="pharmacy_name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="address" class="form-label">Pharmacy Address</label>
                                <input type="text" class="form-control" id="address" name="address" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="contact_number" class="form-label">Contact Number</label>
                                <input type="text" class="form-control" id="contact_number" name="contact_number" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="pharmacy_email" class="form-label">Pharmacy Email</label>
                                <input type="email" class="form-control" id="pharmacy_email" name="pharmacy_email" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Register</button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-3">
                            <a href="login.php">Already have an account? Login here</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 