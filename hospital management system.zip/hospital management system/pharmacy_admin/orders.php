<?php
session_start();
require '../db.php';

// Check if user is logged in and is a pharmacy admin
if (!isset($_SESSION['pharmacy_admin_id']) || !isset($_SESSION['pharmacy_id'])) {
    header("Location: login.php");
    exit;
}

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    try {
        // Start transaction
        $conn->beginTransaction();

        // Update order status
        $stmt = $conn->prepare("
            UPDATE medicine_orders 
            SET status = ? 
            WHERE order_id = ? AND pharmacy_id = ?
        ");
        $stmt->execute([$status, $order_id, $_SESSION['pharmacy_id']]);

        // If order is completed, update medicine quantity
        if ($status === 'completed') {
            // Get order details
            $stmt = $conn->prepare("
                SELECT medicine_id, quantity 
                FROM medicine_orders 
                WHERE order_id = ? AND pharmacy_id = ?
            ");
            $stmt->execute([$order_id, $_SESSION['pharmacy_id']]);
            $order = $stmt->fetch();

            if ($order) {
                // Update medicine quantity
                $stmt = $conn->prepare("
                    UPDATE medicines 
                    SET quantity = quantity + ? 
                    WHERE medicine_id = ? AND pharmacy_id = ?
                ");
                $stmt->execute([$order['quantity'], $order['medicine_id'], $_SESSION['pharmacy_id']]);
            }
        }

        $conn->commit();
        $_SESSION['success_message'] = "Order status updated successfully!";
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error_message'] = "Error: " . $e->getMessage();
    }
}

// Get all orders
$stmt = $conn->prepare("
    SELECT mo.*, m.name as medicine_name 
    FROM medicine_orders mo 
    JOIN medicines m ON mo.medicine_id = m.medicine_id 
    WHERE mo.pharmacy_id = ? 
    ORDER BY mo.order_date DESC
");
$stmt->execute([$_SESSION['pharmacy_id']]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Pharmacy Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Pharmacy Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_medicines.php">Manage Medicines</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sales.php">Sales</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="orders.php">Orders</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Medicine Orders</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Order Date</th>
                                <th>Medicine</th>
                                <th>Quantity</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?php echo date('d M Y H:i', strtotime($order['order_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($order['medicine_name']); ?></td>
                                    <td><?php echo $order['quantity']; ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo match($order['status']) {
                                                'pending' => 'warning',
                                                'approved' => 'info',
                                                'completed' => 'success',
                                                'cancelled' => 'danger',
                                                default => 'secondary'
                                            };
                                        ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($order['status'] === 'pending'): ?>
                                            <form method="POST" action="" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                <input type="hidden" name="status" value="approved">
                                                <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                            </form>
                                            <form method="POST" action="" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                <input type="hidden" name="status" value="cancelled">
                                                <button type="submit" class="btn btn-sm btn-danger">Cancel</button>
                                            </form>
                                        <?php elseif ($order['status'] === 'approved'): ?>
                                            <form method="POST" action="" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                <input type="hidden" name="status" value="completed">
                                                <button type="submit" class="btn btn-sm btn-success">Mark as Completed</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 