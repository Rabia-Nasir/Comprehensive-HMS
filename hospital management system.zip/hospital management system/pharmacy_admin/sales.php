<?php
session_start();
require '../db.php';

// Check if user is logged in and is a pharmacy admin
if (!isset($_SESSION['pharmacy_admin_id']) || !isset($_SESSION['pharmacy_id'])) {
    header("Location: login.php");
    exit;
}

// Handle new sale
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $total_amount = $quantity * $price;

    try {
        // Start transaction
        $conn->beginTransaction();

        // Check if medicine exists and has enough quantity
        $stmt = $conn->prepare("SELECT quantity FROM medicines WHERE medicine_id = ? AND pharmacy_id = ?");
        $stmt->execute([$medicine_id, $_SESSION['pharmacy_id']]);
        $medicine = $stmt->fetch();

        if (!$medicine) {
            throw new Exception("Medicine not found");
        }

        if ($medicine['quantity'] < $quantity) {
            throw new Exception("Not enough quantity in stock");
        }

        // Record the sale
        $stmt = $conn->prepare("
            INSERT INTO medicine_sales (pharmacy_id, medicine_id, quantity, price, total_amount) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$_SESSION['pharmacy_id'], $medicine_id, $quantity, $price, $total_amount]);

        // Update medicine quantity
        $stmt = $conn->prepare("
            UPDATE medicines 
            SET quantity = quantity - ? 
            WHERE medicine_id = ? AND pharmacy_id = ?
        ");
        $stmt->execute([$quantity, $medicine_id, $_SESSION['pharmacy_id']]);

        $conn->commit();
        $_SESSION['success_message'] = "Sale recorded successfully!";
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error_message'] = "Error: " . $e->getMessage();
    }
}

// Get all medicines for dropdown
$stmt = $conn->prepare("SELECT * FROM medicines WHERE pharmacy_id = ? AND quantity > 0 ORDER BY name");
$stmt->execute([$_SESSION['pharmacy_id']]);
$medicines = $stmt->fetchAll();

// Get sales history
$stmt = $conn->prepare("
    SELECT ms.*, m.name as medicine_name 
    FROM medicine_sales ms 
    JOIN medicines m ON ms.medicine_id = m.medicine_id 
    WHERE ms.pharmacy_id = ? 
    ORDER BY ms.sale_date DESC
");
$stmt->execute([$_SESSION['pharmacy_id']]);
$sales = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Management - Pharmacy Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Pharmacy Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_medicines.php">Manage Medicines</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="sales.php">Sales</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">Orders</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Record New Sale</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="medicine_id" class="form-label">Medicine</label>
                                <select class="form-select" id="medicine_id" name="medicine_id" required>
                                    <option value="">Select Medicine</option>
                                    <?php foreach ($medicines as $medicine): ?>
                                        <option value="<?php echo $medicine['medicine_id']; ?>" 
                                                data-price="<?php echo $medicine['price']; ?>"
                                                data-quantity="<?php echo $medicine['quantity']; ?>">
                                            <?php echo htmlspecialchars($medicine['name']); ?> 
                                            (₹<?php echo number_format($medicine['price'], 2); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label">Price per Unit</label>
                                <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                            </div>
                            <div class="mb-3">
                                <label for="total_amount" class="form-label">Total Amount</label>
                                <input type="number" class="form-control" id="total_amount" readonly>
                            </div>
                            <button type="submit" class="btn btn-primary">Record Sale</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Sales History</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Medicine</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($sales as $sale): ?>
                                        <tr>
                                            <td><?php echo date('d M Y H:i', strtotime($sale['sale_date'])); ?></td>
                                            <td><?php echo htmlspecialchars($sale['medicine_name']); ?></td>
                                            <td><?php echo $sale['quantity']; ?></td>
                                            <td>₹<?php echo number_format($sale['price'], 2); ?></td>
                                            <td>₹<?php echo number_format($sale['total_amount'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Calculate total amount when quantity or price changes
        document.getElementById('medicine_id').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            if (selectedOption.value) {
                document.getElementById('price').value = selectedOption.dataset.price;
                calculateTotal();
            }
        });

        document.getElementById('quantity').addEventListener('input', calculateTotal);
        document.getElementById('price').addEventListener('input', calculateTotal);

        function calculateTotal() {
            const quantity = parseFloat(document.getElementById('quantity').value) || 0;
            const price = parseFloat(document.getElementById('price').value) || 0;
            document.getElementById('total_amount').value = (quantity * price).toFixed(2);
        }
    </script>
</body>
</html> 