<?php
session_start();
require '../db.php';

// Check if user is logged in and is a pharmacy admin
if (!isset($_SESSION['pharmacy_admin_id']) || !isset($_SESSION['pharmacy_id'])) {
    header("Location: login.php");
    exit;
}

// Handle form submission for adding/updating medicines
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $manufacturer = $_POST['manufacturer'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $expiry_date = $_POST['expiry_date'];

    try {
        if (isset($_POST['medicine_id'])) {
            // Update existing medicine
            $stmt = $conn->prepare("
                UPDATE medicines 
                SET name = ?, description = ?, manufacturer = ?, category = ?, 
                    price = ?, quantity = ?, expiry_date = ? 
                WHERE medicine_id = ? AND pharmacy_id = ?
            ");
            $stmt->execute([$name, $description, $manufacturer, $category, $price, $quantity, $expiry_date, $_POST['medicine_id'], $_SESSION['pharmacy_id']]);
            $_SESSION['success_message'] = "Medicine updated successfully!";
        } else {
            // Add new medicine
            $stmt = $conn->prepare("
                INSERT INTO medicines (pharmacy_id, name, description, manufacturer, category, price, quantity, expiry_date) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$_SESSION['pharmacy_id'], $name, $description, $manufacturer, $category, $price, $quantity, $expiry_date]);
            $_SESSION['success_message'] = "Medicine added successfully!";
        }
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error: " . $e->getMessage();
    }
}

// Get all medicines for this pharmacy
$stmt = $conn->prepare("SELECT * FROM medicines WHERE pharmacy_id = ? ORDER BY name");
$stmt->execute([$_SESSION['pharmacy_id']]);
$medicines = $stmt->fetchAll();

// Get medicine categories
$stmt = $conn->prepare("SELECT * FROM medicine_categories ORDER BY name");
$stmt->execute();
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Medicines - Pharmacy Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Pharmacy Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_medicines.php">Manage Medicines</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sales.php">Sales</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">Orders</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Add New Medicine</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="name" class="form-label">Medicine Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="manufacturer" class="form-label">Manufacturer</label>
                                <input type="text" class="form-control" id="manufacturer" name="manufacturer">
                            </div>
                            <div class="mb-3">
                                <label for="category" class="form-label">Category</label>
                                <select class="form-select" id="category" name="category">
                                    <option value="">Select Category</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo htmlspecialchars($category['name']); ?>">
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label">Price</label>
                                <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                            </div>
                            <div class="mb-3">
                                <label for="quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="quantity" name="quantity" required>
                            </div>
                            <div class="mb-3">
                                <label for="expiry_date" class="form-label">Expiry Date</label>
                                <input type="date" class="form-control" id="expiry_date" name="expiry_date">
                            </div>
                            <button type="submit" class="btn btn-primary">Add Medicine</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Medicine Inventory</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Expiry Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($medicines as $medicine): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($medicine['name']); ?></td>
                                            <td><?php echo htmlspecialchars($medicine['category']); ?></td>
                                            <td>₹<?php echo number_format($medicine['price'], 2); ?></td>
                                            <td><?php echo $medicine['quantity']; ?></td>
                                            <td><?php echo $medicine['expiry_date'] ? date('d M Y', strtotime($medicine['expiry_date'])) : 'N/A'; ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary edit-medicine" 
                                                        data-id="<?php echo $medicine['medicine_id']; ?>"
                                                        data-name="<?php echo htmlspecialchars($medicine['name']); ?>"
                                                        data-description="<?php echo htmlspecialchars($medicine['description']); ?>"
                                                        data-manufacturer="<?php echo htmlspecialchars($medicine['manufacturer']); ?>"
                                                        data-category="<?php echo htmlspecialchars($medicine['category']); ?>"
                                                        data-price="<?php echo $medicine['price']; ?>"
                                                        data-quantity="<?php echo $medicine['quantity']; ?>"
                                                        data-expiry="<?php echo $medicine['expiry_date']; ?>">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <a href="delete_medicine.php?id=<?php echo $medicine['medicine_id']; ?>" 
                                                   class="btn btn-sm btn-danger"
                                                   onclick="return confirm('Are you sure you want to delete this medicine?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Edit medicine functionality
        document.querySelectorAll('.edit-medicine').forEach(button => {
            button.addEventListener('click', function() {
                const form = document.querySelector('form');
                form.querySelector('#name').value = this.dataset.name;
                form.querySelector('#description').value = this.dataset.description;
                form.querySelector('#manufacturer').value = this.dataset.manufacturer;
                form.querySelector('#category').value = this.dataset.category;
                form.querySelector('#price').value = this.dataset.price;
                form.querySelector('#quantity').value = this.dataset.quantity;
                form.querySelector('#expiry_date').value = this.dataset.expiry;
                
                // Add hidden input for medicine_id
                let hiddenInput = form.querySelector('input[name="medicine_id"]');
                if (!hiddenInput) {
                    hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = 'medicine_id';
                    form.appendChild(hiddenInput);
                }
                hiddenInput.value = this.dataset.id;
                
                // Change button text
                form.querySelector('button[type="submit"]').textContent = 'Update Medicine';
                
                // Scroll to form
                form.scrollIntoView({ behavior: 'smooth' });
            });
        });
    </script>
</body>
</html> 