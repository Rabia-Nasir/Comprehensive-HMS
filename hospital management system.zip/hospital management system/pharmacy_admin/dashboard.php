<?php
session_start();
require '../db.php';

// Check if user is logged in and is a pharmacy admin
if (!isset($_SESSION['pharmacy_admin_id']) || !isset($_SESSION['pharmacy_id'])) {
    header("Location: login.php");
    exit;
}

// Get pharmacy information
$stmt = $conn->prepare("SELECT * FROM pharmacies WHERE pharmacy_id = ?");
$stmt->execute([$_SESSION['pharmacy_id']]);
$pharmacy = $stmt->fetch();

// Get medicines
$stmt = $conn->prepare("SELECT * FROM medicines WHERE pharmacy_id = ?");
$stmt->execute([$_SESSION['pharmacy_id']]);
$medicines = $stmt->fetchAll();

// Get recent sales
$stmt = $conn->prepare("
    SELECT ms.*, m.name as medicine_name 
    FROM medicine_sales ms 
    JOIN medicines m ON ms.medicine_id = m.medicine_id 
    WHERE ms.pharmacy_id = ? 
    ORDER BY ms.sale_date DESC 
    LIMIT 5
");
$stmt->execute([$_SESSION['pharmacy_id']]);
$sales = $stmt->fetchAll();

// Get pending orders
$stmt = $conn->prepare("
    SELECT mo.*, m.name as medicine_name 
    FROM medicine_orders mo 
    JOIN medicines m ON mo.medicine_id = m.medicine_id 
    WHERE mo.pharmacy_id = ? AND mo.status = 'pending' 
    ORDER BY mo.order_date DESC
");
$stmt->execute([$_SESSION['pharmacy_id']]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Pharmacy Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="manage_medicines.php">Manage Medicines</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sales.php">Sales</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">Orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">Inventory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Pharmacy Information</h4>
                    </div>
                    <div class="card-body">
                        <p><strong>Pharmacy Name:</strong> <?php echo htmlspecialchars($pharmacy['name']); ?></p>
                        <p><strong>Address:</strong> <?php echo htmlspecialchars($pharmacy['address']); ?></p>
                        <p><strong>Contact:</strong> <?php echo htmlspecialchars($pharmacy['contact_number']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($pharmacy['email']); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Medicine Inventory</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($medicines)): ?>
                            <p>No medicines in inventory.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Medicine</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($medicines as $medicine): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($medicine['name']); ?></td>
                                                <td><?php echo htmlspecialchars($medicine['quantity']); ?></td>
                                                <td>₹<?php echo htmlspecialchars($medicine['price']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $medicine['quantity'] > 0 ? 'success' : 'danger'; ?>">
                                                        <?php echo $medicine['quantity'] > 0 ? 'In Stock' : 'Out of Stock'; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        <a href="manage_medicines.php" class="btn btn-primary">Manage Medicines</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Recent Sales</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($sales)): ?>
                            <p>No recent sales.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Medicine</th>
                                            <th>Quantity</th>
                                            <th>Amount</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($sales as $sale): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($sale['medicine_name']); ?></td>
                                                <td><?php echo htmlspecialchars($sale['quantity']); ?></td>
                                                <td>₹<?php echo htmlspecialchars($sale['total_amount']); ?></td>
                                                <td><?php echo date('d M Y H:i', strtotime($sale['sale_date'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        <a href="sales.php" class="btn btn-primary">View All Sales</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Pending Orders</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($orders)): ?>
                            <p>No pending orders.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Medicine</th>
                                            <th>Quantity</th>
                                            <th>Order Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orders as $order): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($order['medicine_name']); ?></td>
                                                <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                                                <td><?php echo date('d M Y H:i', strtotime($order['order_date'])); ?></td>
                                                <td>
                                                    <span class="badge bg-warning">Pending</span>
                                                </td>
                                                <td>
                                                    <a href="process_order.php?id=<?php echo $order['order_id']; ?>&action=approve" class="btn btn-success btn-sm">Approve</a>
                                                    <a href="process_order.php?id=<?php echo $order['order_id']; ?>&action=cancel" class="btn btn-danger btn-sm">Cancel</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        <a href="orders.php" class="btn btn-primary">View All Orders</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 